Placeholder files for Demo project 3. Nothing real here.
